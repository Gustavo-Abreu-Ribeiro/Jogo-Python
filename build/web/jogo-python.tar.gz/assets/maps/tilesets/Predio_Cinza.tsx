<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Predio_Cinza" tilewidth="16" tileheight="16" tilecount="169" columns="13">
 <image source="../../sprites/post_apocalypse/Tiles/Buildings/Buildings_gray_TileSet.png" width="208" height="208"/>
</tileset>

