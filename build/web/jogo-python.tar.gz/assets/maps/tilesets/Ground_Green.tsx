<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Ground_Green" tilewidth="16" tileheight="16" tilecount="408" columns="24">
 <image source="../../sprites/post_apocalypse/Tiles/Background_Green_TileSet.png" width="384" height="272"/>
</tileset>

