from __future__ import annotations

from typing import Dict, List, Tuple

from inventory import Inventory


class CraftingSystem:

    crafting_recipes: Dict[str, Dict[str, object]] = {
        "taco": {"cost": {"madeira": 3}},
        "balas": {"cost": {"metal": 1, "polvora": 1}, "amount": 6},
        "kit_medico": {"cost": {"pano": 2, "erva": 2}},
    }

    def craft(self, item_name: str, inventory: Inventory) -> Tuple[bool, str]:
        if item_name not in self.crafting_recipes:
            return False, "Receita inexistente."

        recipe = self.crafting_recipes[item_name]
        recipe_cost = recipe["cost"]

        if not inventory.has_items(recipe_cost):
            return False, "Recursos insuficientes."

        for item, amount in recipe_cost.items():
            inventory.remove_item(item, amount)

        amount = int(recipe.get("amount", 1))
        inventory.add_item(item_name, amount)
        suffix = f" x{amount}" if amount > 1 else ""
        return True, f"Criado: {item_name}{suffix}."

    def get_recipe_names(self) -> List[str]:
        return list(self.crafting_recipes.keys())

    def get_recipe(self, item_name: str) -> Dict[str, object] | None:
        return self.crafting_recipes.get(item_name)
